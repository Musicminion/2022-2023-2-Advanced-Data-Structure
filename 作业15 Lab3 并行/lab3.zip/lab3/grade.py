#!/usr/bin/env python
import os

def main():
    test_suite = {
        "triangle": (10, 100, 1000, 10000),
        "matrix": (10, 100, 1000, 2000),
    }
    os.system("make -B")
    score = 0
    for name, size_list in test_suite.items():
        for sz in size_list:
            print("---Testing %s %d---" % (name, sz))
            rc = os.system("./test %s %d" % (name, sz))
            print("Result:%s" % "Pass" if rc == 0 else "Failed")
            score += 10 * (rc == 0)
    print(">>>>>>> SCORE: %d <<<<<<<" % score)

if __name__ == '__main__':
    main()

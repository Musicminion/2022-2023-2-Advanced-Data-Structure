1. test.cc中已给出两个示例问题的单线程实现，你的任务是将`solve_triangle`和`solve_matrix`两个问题替换为并行实现。
2. 代码本地评测：`python3 grade.py`
3. 完成后将文件夹压缩为zip提交，命名为学号+姓名+lab3，如“520123456789+张三+lab3.zip”。
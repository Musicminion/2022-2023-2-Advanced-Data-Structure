#include <ios>
#include <array>
#include <iostream>
#include <cstdio>
#include <cstdint>
#include <string>
#include <fstream>
#include <cassert>
#include "util.h"

constexpr static int32_t MOD = 1e9 + 7;

int64_t **alloc_2darr(int32_t n) {
    int64_t** arr_2d = new int64_t* [n];
    for (int32_t i = 0; i < n; i++) {
        arr_2d[i] = new int64_t[n];
    }
    return arr_2d;
}

void free_2darr(int64_t **arr_2d, int32_t n) {
    for (int32_t i = 0; i < n; i ++ ) {
        delete[] arr_2d[i];
    }
    delete[] arr_2d;
}

int32_t solve_triangle(int64_t **f, int32_t n) {
    /* TODO: yout code here. make following algorithm parallel */
    f[0][0] = 1;
    for (int32_t i = 1; i <= n; i ++ )
        for (int32_t j = 1; j <= n; j ++ )
            f[i][j] = (f[i - 1][j] + f[i - 1][j - 1]) % MOD;
    return f[n][n / 2];
}

void solve_matrix(int64_t **A, int64_t **B, int64_t **C, int32_t n) {
    /* TODO: yout code here. make following algorithm parallel */
    for (int32_t i = 1; i <= n; i ++ )
        for (int32_t j = 1; j <= n; j ++ )
            for (int32_t k = 1; k <= n; k ++ )
                C[i][j] = (C[i][j] + A[i][k] * B[k][j]) % MOD;
}

void generate_output(const std::string &test_problem,
        const int32_t data_size, const std::string &output_path) {

    JudgeFile output_file(output_path, std::ios_base::out);
    auto &fout = output_file.get();

    if (test_problem == "triangle") {
        auto f = alloc_2darr(data_size + 1);
        auto ans = solve_triangle(f, data_size);
        free_2darr(f, data_size + 1);
        f = nullptr;
        fout << ans << std::endl;
    } else if (test_problem == "matrix") {
        auto input_path = "./data/" + test_problem + "-" + std::to_string(data_size) + ".txt";
        JudgeFile input_file(input_path, std::ios_base::in);
        auto &fin = input_file.get();
        auto A = alloc_2darr(data_size + 1);
        auto B = alloc_2darr(data_size + 1);
        auto C = alloc_2darr(data_size + 1);
        for (int32_t i = 1; i <= data_size; i ++ )
            for (int32_t j = 1; j <= data_size; j ++ )
                fin >> A[i][j];
        for (int32_t i = 1; i <= data_size; i ++ )
            for (int32_t j = 1; j <= data_size; j ++ )
                fin >> B[i][j];
        solve_matrix(A, B, C, data_size);
        for (int32_t i = 1; i <= data_size; i ++ ) {
            for (int32_t j = 1; j <= data_size; j ++ ) {
                fout << C[i][j] << " ";
            }
            fout << std::endl;
        }
        free_2darr(A, data_size + 1);
        free_2darr(B, data_size + 1);
        free_2darr(C, data_size + 1);
        A = B = C = nullptr;
    } else {
        assert(0);
    }
}

bool check_answer(const std::string &output_path, const std::string &answer_path,
        const std::string &test_problem, int32_t data_size) {

    JudgeFile output_file(output_path, std::ios_base::in);
    JudgeFile answer_file(answer_path, std::ios_base::in);
    auto &out_handle = output_file.get();
    auto &ans_handle = answer_file.get();
    std::string ol, al;
    bool ret;

    for (int32_t lineno = 0; !out_handle.eof() && !ans_handle.eof(); lineno ++ ) {
        getline(out_handle, ol);
        getline(ans_handle, al);
        if (trim(ol) != trim(al)) {
            std::cerr << "ERROR: Failed at " << test_problem <<
                "-" << data_size << " line:" << lineno << 
                " output:" << ol << " answer:" << al << std::endl;
            return false;
        }
    }
    if (!(ret = out_handle.eof() && ans_handle.eof())) {
        std::cerr << "ERROR: Line number miss match" << std::endl;
    }
    return ret;
}

int main (int argc, char *argv[]) {
    assert(argc == 3);
    std::string test_problem(argv[1]);
    auto data_size = std::stoi(argv[2]);
    auto output_path = "./data/" + test_problem + "-" + std::to_string(data_size) + ".out";
    auto answer_path = "./data/" + test_problem + "-" + std::to_string(data_size) + ".ans";

    try {
        generate_output(test_problem, data_size, output_path);
        if (check_answer(output_path, answer_path, test_problem, data_size))
            return 0;
    } catch(std::exception &e) {
        std::cerr << e.what() << std::endl;
        return -1;
    }
    return -1;
}
